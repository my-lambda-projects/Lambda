import React from "react";

const Display = () => {
  return <div className="display">{/* Display any props data here */}</div>;
};
