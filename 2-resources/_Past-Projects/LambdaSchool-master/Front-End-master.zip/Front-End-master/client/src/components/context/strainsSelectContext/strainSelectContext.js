import { createContext } from 'react';

const StrainSelectContext = createContext();

export default StrainSelectContext;