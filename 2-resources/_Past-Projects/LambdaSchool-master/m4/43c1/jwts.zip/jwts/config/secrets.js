module.exports = {
  jwtSecret: process.env.JWTKEY || "is it secret, is it safe?",
};
