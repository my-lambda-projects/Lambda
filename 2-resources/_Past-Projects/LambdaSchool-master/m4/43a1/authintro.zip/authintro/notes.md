# Authentication Notes
